# Discord Whitelist Bot

A Discord bot for managing Roblox whitelists using Firebase.